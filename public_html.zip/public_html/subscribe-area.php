<section class="subscribe-area">
        <div class="container">
            <div class="row align-items-center">
                <!-- Subscribe Text -->
                <div class="col-12">
                    <div class="subscribe-text">
                        <h3 style="text-align: center;">Yo te instruiré, yo te mostraré el camino que debes seguir.</h3>
                        <h6 style="text-align: center;">Salmos 32:8</h6>
                    </div>
                </div>
                <!-- Subscribe Form -->
                <!--<div class="col-12 col-lg-6">
                    <div class="subscribe-form text-right">
                        <form action="#">
                            <input type="email" name="subscribe-email" id="subscribeEmail" placeholder="Your Email">
                            <button type="submit" class="btn crose-btn">subscribe</button>
                        </form>
                    </div>
                </div>-->
            </div>
        </div>
    </section>