<footer class="footer-area">
        <!-- Main Footer Area -->
        <div class="main-footer-area">
            <div class="container">
                <div class="row">

                    <!-- Single Footer Widget -->
                    <div class="col-12 col-lg-9">
                        <div class="single-footer-widget mb-70">
                            <a class="footer-logo"><img style="width: 30%;" src="img/core-img/Logo_Santiago_Apostol_wide_white_text.png" alt=""></a>
                            <p style="text-align: justify;">Parroquia de Santiago Apóstol, conformada por 15 comunidades, a cargo de nuestro párroco, el Pbro. Alejandro Hernández Sánchez, en coordinación de un comité organizador y encargados de la parroquia, invitamos a evangelizar a los pueblos con el evangelio que Dios, nuestro Señor, nos ha enviado.</p>
                        </div>
                    </div>

                    <!-- Single Footer Widget -->
                    <!--<div class="col-12 col-sm-6 col-lg-3">
                        <div class="single-footer-widget mb-70">
                            <h5 class="widget-title">Quick Link</h5>
                            <nav class="footer-menu">
                                <ul>
                                    <li><a href="#"><i class="fa fa-angle-double-right" aria-hidden="true"></i> Home</a></li>
                                    <li><a href="#"><i class="fa fa-angle-double-right" aria-hidden="true"></i> Event</a></li>
                                    <li><a href="#"><i class="fa fa-angle-double-right" aria-hidden="true"></i> About Us</a></li>
                                    <li><a href="#"><i class="fa fa-angle-double-right" aria-hidden="true"></i> Gallery</a></li>
                                    <li><a href="#"><i class="fa fa-angle-double-right" aria-hidden="true"></i> Sermons</a></li>
                                    <li><a href="#"><i class="fa fa-angle-double-right" aria-hidden="true"></i> Contact</a></li>
                                    <li><a href="#"><i class="fa fa-angle-double-right" aria-hidden="true"></i> Blogs</a></li>
                                    <li><a href="#"><i class="fa fa-angle-double-right" aria-hidden="true"></i> Donate</a></li>
                                </ul>
                            </nav>
                        </div>
                    </div>-->

                    <!-- Single Footer Widget -->
                    <!--<div class="col-12 col-sm-6 col-lg-3">
                        <div class="single-footer-widget mb-70">
                            <h5 class="widget-title">News Latest</h5>-->

                            <!-- Single Latest News -->
                            <!--<div class="single-latest-news">
                                <a href="#">Polish schools in UK warned</a>
                                <p><i class="fa fa-calendar" aria-hidden="true"></i> November 11, 2017</p>
                            </div>-->

                            <!-- Single Latest News -->
                            <!--<div class="single-latest-news">
                                <a href="#">University league tables 2018</a>
                                <p><i class="fa fa-calendar" aria-hidden="true"></i> November 11, 2017</p>
                            </div>

                        </div>
                    </div>-->

                    <!-- Single Footer Widget -->
                    <div class="col-12 col-sm-6 col-lg-3">
                        <div class="single-footer-widget mb-70">
                            <h5 class="widget-title">Contacto</h5>

                            <div class="contact-information">
                                <a href="https://goo.gl/maps/mkJcAjgGYsUyNCVo8"><i class="fa fa-map-marker" aria-hidden="true"></i> José M. Morelos 14, El Fitzhi, 42300, Ixmiquilpan, Hgo.</a>
                                <!--<p><i class="fa fa-phone" aria-hidden="true"></i> 772-106-7928 | 772-121-3888</p>-->
                                <!--<a href="mailto:info.deercreative@gmail.com"><i class="fa fa-envelope" aria-hidden="true"></i> info.deercreative@gmail.com</a>-->
                                <p><i class="fa fa-clock-o" aria-hidden="true"></i> Lunes a Viernes: 8 am - 8 pm</p>
                            </div>

                        </div>
                    </div>

                </div>
            </div>
        </div>

        <!-- Copwrite Area -->
        <div class="copywrite-area">
            <div class="container h-100">
                <div class="row h-100 align-items-center flex-wrap">
                    <!-- Copywrite Text -->
                    <div class="col-12 col-md-6">
                        <div class="copywrite-text">
                            <p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
</p>
                        </div>
                    </div>

                    <!-- Footer Social Icon -->
                    <div class="col-12 col-md-6">
                        <div class="footer-social-icon">
                            <a href="https://www.facebook.com/pages/category/Religious-Organization/Parroquia-De-Santiago-Apóstol-El-Fithzi-269352419755459/"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                            <!--<a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                            <a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a>
                            <a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a>-->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>