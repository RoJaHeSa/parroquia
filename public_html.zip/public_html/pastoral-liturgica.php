<!DOCTYPE html>
<html lang="es">

<head>
    <title>Parroquia de Santiago Apóstol | Pastoral litúrgica</title>
    <?php include 'head.php' ?>
</head>

<body>
    <!-- ##### Preloader ##### -->
    <div class="preloader d-flex align-items-center justify-content-center">
        <!-- Line -->
        <div class="line-preloader"></div>
    </div>

    <!-- ##### Header Area Start ##### -->
        <?php include 'header.php'; ?>
    <!-- ##### Header Area End ##### -->

    <!-- ##### Breadcrumb Area Start ##### -->
    <div class="breadcrumb-area">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="index.php">Inicio</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Litúrgica</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <!-- ##### Breadcrumb Area End ##### -->

    <!-- ##### About Us Area Start ##### -->
    <div class="about-us-area about-page section-padding-100">
        <div class="container">
            <div class="row align-items-center justify-content-between">
                <div class="col-12 col-lg-5">
                    <div class="about-content">
                        <h2>Pastoral litúrgica</h2>
                        <!--<h3>Objetivo</h3>-->
                        <p style="text-align: justify;">La pastoral litúrgica es el conjunto de acciones que realiza la Iglesia para facilitar la participación activa y consciente del pueblo de Dios en la Liturgia. Es también la ciencia y el arte de convertir los signos del culto cristiano en lo más comunicativo posible para favorecer la participación.
                        </p>
                        <div class="opening-hours-location mt-30 d-flex align-items-center">
                            <!-- Botón de integrantes -->
                            <div class="opening-hours">
                                <!--<h6><i class="fa fa-clock-o"></i> Opening Hours</h6>
                                <p>Mon - Fri at 08:00 - 21:00 <br>Sunday at 09:00 - 18:00</p>-->
                                <button data-toggle="modal" data-target="#modalIntegrantes" class="btn crose-btn btn-lg btn-block"><i class="fa fa-user-o"></i> Integrantes</button>
                            </div>
                            <!-- Botón de misión -->
                            <div class="opening-hours">
                                <!--<h6><i class="fa fa-map-marker"></i> Location</h6>
                                <p>No 40 Baria Sreet 133/2 NewYork City, NY, United States</p>-->
                                <button data-toggle="modal" data-target="#modalObjetivo" class="btn crose-btn btn-lg btn-block"><i class="fa fa-line-chart"></i> Objetivo</button>
                            </div>
                        </div>
                        <div class="opening-hours-location mt-30 d-flex align-items-center">
                            <!-- Botón de visión -->
                            <div class="opening-hours">
                                <!--<h6><i class="fa fa-clock-o"></i> Opening Hours</h6>
                                <p>Mon - Fri at 08:00 - 21:00 <br>Sunday at 09:00 - 18:00</p>-->
                                <button data-toggle="modal" data-target="#modalPresentacion" class="btn crose-btn btn-lg btn-block"><i class="fa fa-file-text"></i> Dimensiones</button>
                            </div>
                            <!-- Botón de valores -->
                            <div class="opening-hours">
                                <!--<h6><i class="fa fa-map-marker"></i> Location</h6>
                                <p>No 40 Baria Sreet 133/2 NewYork City, NY, United States</p>-->
                                <button data-toggle="modal" data-target="#modalLogros" class="btn crose-btn btn-lg btn-block"><i class="fa fa-question-circle-o"></i> Informes</button>
                            </div>
                        </div>
                        <!--<div class="opening-hours-location mt-30 d-flex align-items-center">
                            <div class="opening-hours">
                                <button data-toggle="modal" data-target="#modalResponsables" class="btn crose-btn btn-lg btn-block"><i class="fa fa-exclamation-circle"></i> Responsables</button>
                            </div>
                        </div>-->
                    </div>
                </div>
                <div class="col-12 col-lg-6">
                    <div class="about-thumbnail">
                        <img src="img/bg-img/pastoral-liturgica/1.jpg" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ##### About Us Area End ##### -->

    <!-- #### Modales #### -->
    <!-- Modal Integrantes -->
    <div class="modal fade" id="modalIntegrantes" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    	<div class="modal-dialog" role="document">
    		<div class="modal-content">
    			<div class="modal-header">
    				<h4 style="text-align: left;" class="modal-title" id="myModalLabel">Quienes integran</h4>
    				<button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
    					<span aria-hidden="true">&times;</span>
    				</button>
    			</div>
    			<div style="text-align: justify;" class="modal-body">
    			    <img src="img/bg-img/pastoral-liturgica/2.jpg" alt="">
    				<br></br>
    				<h5>Coordinadora</h5>
                	<p style="margin-left: 20px;">Nohemí L. Martínez Reséndiz, Sujey Sauza</p>
                	
                	<br></br>
                	
                	<h5>Comunidades</h5>
                	<table class="table table-striped">
                	    <thead>
                	        <tr>
                    	        <th>Comunidad</th>
                    	        <th>Responsable</th>
                	        </tr>
                	    </thead>
                	    <tbody>
                	        <tr>
                	            <th>El Fithzi</th>
                	            <td>Hermilo González Ramírez</td>
                	        </tr>
                	        <tr>
                	            <th>Jesús</th>
                	            <td>Rosalinda de la Concha</td>
                	        </tr>
                	        <tr>
                	            <th>Dios Padre</th>
                	            <td>Inés Hernández Peña</td>
                	        </tr>
                	        <tr>
                	            <th>Pueblo Nuevo</th>
                	            <td>Rufina Cazuela Biñuelo</td>
                	        </tr>
                	        <tr>
                	            <th>El Tephé</th>
                	            <td>Ma. Antonieta Marcelo V.</td>
                	        </tr>
                	        <tr>
                	            <th>Taxadho</th>
                	            <td>Juliana Villa</td>
                	        </tr>
                	        <tr>
                	            <th>Cañada Chica</th>
                	            <td>Isabel Ortiz Ortiz</td>
                	        </tr>
                	        <tr>
                	            <th>Maguey Blanco</th>
                	            <td>Alejandra Catalán M.</td>
                	        </tr>
                	        <tr>
                	            <th>El Tablón</th>
                	            <td>Reyna Jerónimo Pérez</td>
                	        </tr>
                	        <tr>
                	            <th>El Alberto</th>
                	            <td>Amalia Agustín Santiago</td>
                	        </tr>
                	        <tr>
                	            <th>El Barrido</th>
                	            <td>Ergia García Muñoz</td>
                	        </tr>
                	    </tbody>
                	</table>
    			</div>
    		</div>
    	</div>
	</div>
	
	<!-- Modal Misión -->
	<div class="modal fade" id="modalObjetivo" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    	<div class="modal-lg modal-dialog" role="document">
    		<div class="modal-content">
    			<div class="modal-header">
    				<h4 style="text-align: left;" class="modal-title" id="myModalLabel">Objetivo</h4>
    				<button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
    					<span aria-hidden="true">&times;</span>
    				</button>
    			</div>
    			<div style="text-align: justify;" class="modal-body">
    			    <img src="img/bg-img/pastoral-liturgica/3.jpg" alt="">
    				<br></br>
    				Al hablar de pastoral litúrgica, hacemos referencia a un campo más amplio que el solamente contenido en el momento de la celebración litúrgica y el seguimiento de las rúbricas. Se contemplan los momentos anteriores a la celebración: adecuada elección de los textos y formularios disponibles para la celebración, organización y capacitación de los diversos ministros y ministerios, formación o catequesis mistagógica de la asamblea celebrante; los momentos posteriores a la misma: compromiso apostólico de los bautizados, inserción de las celebraciones rituales en los procesos de pastoral de conjunto, etc.  Además, se contemplan otras celebraciones, acciones de piedad y religiosidad popular, ya sean de carácter privado o público, que deben ser encaminadas hacia el Misterio de Cristo y su Iglesia.
    				<br></br>
    				Las acciones de pastoral litúrgica también buscan que todos los que participan de la asamblea, comprendan e interioricen los avances y el proceso de perfeccionamiento que vive la liturgia, —sintetizados en las nuevas ediciones de los rituales—; así, la reforma litúrgica emprendida por el Concilio Vaticano II, continúa en nuestras comunidades, a través de la difusión, conocimiento y capacitación en el uso de los libros litúrgicos.   La pastoral litúrgica ha de lograr que los signos y símbolos de la Liturgia sean cercanos a los hombres y mujeres y den sentido a sus actuales circunstancias.
    			</div>
    		</div>
    	</div>
	</div>
	
	<!-- Modal Visión -->
	<div class="modal fade" id="modalPresentacion" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    	<div class="modal-dialog" role="document">
    		<div class="modal-content">
    			<div class="modal-header">
    				<h4 style="text-align: left;" class="modal-title" id="myModalLabel">Dimensiones</h4>
    				<button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
    					<span aria-hidden="true">&times;</span>
    				</button>
    			</div>
    			<div style="text-align: justify;" class="modal-body">
    			    <img src="img/bg-img/pastoral-liturgica/4.jpg" alt="">
    				<br></br>
    				<p>
    				    <b>• Monaguillos</b>
    				    <p style="padding-left: 20px;">Los monaguillos son ministros, niños o jóvenes, que asisten al sacerdote, en todas las celebraciones de la liturgia y procesiones. Los monaguillos desempeñan diversas funciones en el altar (acompañar al sacerdote, llevar al altar el pan, vino y agua; retirar el cáliz, etc.) con el objeto de ayudar al orden y belleza litúrgica, además de incentivar la participación, la devoción y el recogimiento de los fieles.</p>
				    </p>
    				<p>
                        <b>• Ministros extraordinarios de la Sagrada Comunión</b>
    				    <p style="padding-left: 20px;">Hombres o mujeres comisionados por el Obispo, para asistir en la distribución de la Sagrada Comunión en Misa o bien llevarla a quienes no pueden acudir a la Iglesia a recibirla (enfermos).</p>
                    </p>
                    <p>
                        <b>• Lectores</b>
    				    <p style="padding-left: 20px;">El lector es el encargado de leer la Palabra de Dios en la asamblea litúrgica.</p>
                    </p>
                    <p>
                        <b>• Coros</b>
    				    <table class="table table-striped" style="padding-left: 20px;">
    				        <thead>
    				            <tr>
    				                <th>Coro</th>
    				                <th>Responsable</th>
    				            </tr>
    				        </thead>
    				        <tbody>
    				            <tr>
    				                <th>Canta con el Corazón</th>
    				                <td>Ricardo Molina</td>
    				            </tr>
    				            <tr>
    				                <th>Esperanza de Dios</th>
    				                <td>Edgar Pérez Gómez</td>
    				            </tr>
    				            <tr>
    				                <th>Solo Dios basta</th>
    				                <td>Juan Gabriel Bernal</td>
    				            </tr>
    				        </tbody>
    				    </table>
                    </p>
                    <p>
                        <b>• Mayordomos y/o comités de Fiesta</b>
    				    <p style="padding-left: 20px;">Es una llamada personal que el Señor le hace a cada mayordomo para encargarle una misión en bien de la iglesia y de la comunidad.</p>
                    </p>
                    <p>
                        <b>• Rezanderos</b>
    				    <p style="padding-left: 20px;">Personas que tienen por oficio rezar por los muertos durante los rituales funerarios.</p>
                    </p>
    			</div>
    		</div>
    	</div>
	</div>
	
	<!-- Modal Valores -->
	<div class="modal fade" id="modalLogros" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    	<div class="modal-dialog" role="document">
    		<div class="modal-content">
    			<div class="modal-header">
    				<h4 style="text-align: left;" class="modal-title" id="myModalLabel">Informes</h4>
    				<button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
    					<span aria-hidden="true">&times;</span>
    				</button>
    			</div>
    			<div style="text-align: justify;" class="modal-body">
    			    <!--<img src="img/bg-img/pastoral-liturgica/5.jpg" alt="">
    				<br></br>-->
        			<p>Para mayores informes comunicarse con:<br></br>
                    Nohemí L. Martínez Reséndiz<br></br></p>
                    <a href="mailto:nohemi_lmr@hotmail.com">nohemi_lmr@hotmail.com</a>
    			</div>
    		</div>
    	</div>
	</div>
	
	<!-- Modal Lugar -->
	<div class="modal fade" id="modalResponsables" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    	<div class="modal-lg modal-dialog" role="document">
    		<div class="modal-content">
    			<div class="modal-header">
    				<h4 style="text-align: left;" class="modal-title" id="myModalLabel">Responsables</h4>
    				<button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
    					<span aria-hidden="true">&times;</span>
    				</button>
    			</div>
    			<div style="text-align: justify;" class="modal-body">
    			    <!--<img src="img/bg-img/pastoral-liturgica/6.jpg" alt="">
    				<br></br>-->
    				<table class="table table-striped">
    				    <thead>
    				        <tr>
    				            <th>Área</th>
    				            <th>Responsable</th>
    				            <th>Teléfono</th>
    				            <th>Correo</th>
    				        </tr>
    				    </thead>
    				    <tbody>
    				        <tr>
    				            <th>Prebautismales</th>
    				            <td>Ana María Moreno Ángeles y Vladimir</td>
    				            <td>Cel. 7721288378</td>
    				            <td>nava_5355@hotmail.com</td>
    				        </tr>
    				        <tr>
    				            <th>Escuela para padres</th>
    				            <td>Ana María Moreno Ángeles y Vladimir</td>
    				            <td>Cel. 7721288378</td>
    				            <td>nava_5355@hotmail.com</td>
    				        </tr>
    				        <tr>
    				            <th>Formación para catequistas</th>
    				            <td>Ernestina Ortega Monroy</td>
    				            <td>Cel. 7721192295</td>
    				            <td>soniarodriguezrodriguez13@gmail.com</td>
    				        </tr>
    				        <tr>
    				            <th>Escuela catequeticas</th>
    				            <td>María Ana Mendoza Maldonado</td>
    				            <td>Cel. 7727363015</td>
    				            <td>mema1303_495@hotmail.com</td>
    				        </tr>
    				    </tbody>
    				</table>
    			</div>
    		</div>
    	</div>
	</div>
	
	<!-- ##### Fin del área de modales ##### -->

    <!-- ##### Subscribe Area Start ##### -->
    <?php include 'subscribe-area.php' ?>
    <!-- ##### Subscribe Area End ##### -->

    <!-- ##### Footer Area Start ##### -->
    <?php include 'footer.php' ?>
    <!-- ##### Footer Area End ##### -->

    <!-- ##### All Javascript Script ##### -->
    <!-- jQuery-2.2.4 js -->
    <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="js/bootstrap/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="js/bootstrap/bootstrap.min.js"></script>
    <!-- All Plugins js -->
    <script src="js/plugins/plugins.js"></script>
    <!-- Active js -->
    <script src="js/active.js"></script>
</body>

</html>