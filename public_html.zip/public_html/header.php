<header class="header-area">

        <!-- ***** Top Header Area ***** -->
        <div class="top-header">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="top-header-content d-flex flex-wrap align-items-center justify-content-between">
                            <!-- Top Header Meta -->
                            <div class="top-header-meta d-flex flex-wrap">
                                <a href="#" class="open" data-toggle="tooltip" data-placement="bottom" title="8 am a 8 pm"><i class="fa fa-clock-o" aria-hidden="true"></i> <span>Horario de apertura: 8 am - 8 pm</span></a>
                                <!-- Social Info -->
                                <div class="top-social-info">
                                    <a href="https://www.facebook.com/pages/category/Religious-Organization/Parroquia-De-Santiago-Apóstol-El-Fithzi-269352419755459/"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                                </div>
                            </div>
                            <!-- Top Header Meta -->
                            <!--<div class="top-header-meta">
                                <p class="phone"><i class="fa fa-phone" aria-hidden="true"></i> <span>772-106-7928 | 772-121-3888</span></p>
                            </div>-->
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- ***** Top Header Area ***** -->

        <!-- ***** Navbar Area ***** -->
        <div class="crose-main-menu">
            <div class="classy-nav-container breakpoint-off">
                <div class="container">
                    <!-- Menu -->
                    <nav class="classy-navbar justify-content-between" id="croseNav">

                        <!-- Nav brand -->
                        <a href="index.html" class="nav-brand"><img style="height:50px; position:center;" src="img/core-img/Logo_Santiago_Apostol_wide.png" alt=""></a>

                        <!-- Navbar Toggler -->
                        <div class="classy-navbar-toggler">
                            <span class="navbarToggler"><span></span><span></span><span></span></span>
                        </div>

                        <!-- Menu -->
                        <div class="classy-menu">

                            <!-- close btn -->
                            <div class="classycloseIcon">
                                <div class="cross-wrap"><span class="top"></span><span class="bottom"></span></div>
                            </div>

                            <!-- Nav Start -->
                            <div class="classynav">
                                <ul>
                                    <li><a href="index.php">Inicio</a></li>
                                    <li><a href="index.php#galeria">Galería</a></li>
                                    <li><a href="index.php#anuncios">Anuncios</a></li>
                                    <li><a href="#">Pastorales</a>
                                        <ul class="dropdown">
                                            <li><a href="pastoral-profetica.php">Profética</a></li>
                                            <li><a href="pastoral-liturgica.php">Litúrgica</a></li>
                                            <li><a>Social</a></li>
                                            <li><a>Iglesia comunidad</a></li>
                                            <li><a href="pastoral-familiar.php">Familiar</a></li>
                                            <li><a>Juvenil</a></li>
                                            <li><a href="pastoral-vocacional.php">Vocacional</a></li>
                                            <li><a>Medios de comun.</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="#">Sacramentos</a>
                                        <ul class="dropdown">
                                            <li><a>Bautismo</a></li>
                                            <li><a>Confirmación</a></li>
                                            <li><a>Eucaristía</a></li>
                                            <li><a>Reconciliación</a></li>
                                            <li><a>Unción de los enf.</a></li>
                                            <li><a>Orden sacerdotal</a></li>
                                            <li><a>Matrimonio</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="#">Comunidades</a>
                                        <div class="megamenu">
                                            <ul class="single-mega cn-col-4">
                                                <li><a>Fitzhi</a></li>
                                                <li><a>Barrio de Jesús</a></li>
                                                <li><a>Cantinela</a></li>
                                                <li><a>San Alberto</a></li>
                                            </ul>
                                            <ul class="single-mega cn-col-4">
                                                <li><a>El Tablón</a></li>
                                                <li><a>Dios Padre</a></li>
                                                <li><a>El Valante</a></li>
                                                <li><a>El Barrido</a></li>
                                            </ul>
                                            <ul class="single-mega cn-col-4">
                                                <li><a>El Tephé</a></li>
                                                <li><a>Maguey Blanco</a></li>
                                                <li><a>Pueblo Nuevo</a></li>
                                                <li><a>La Loma de Pueblo Nuevo</a></li>
                                            </ul>
                                            <ul class="single-mega cn-col-4">
                                                <li><a>Taxadho</a></li>
                                                <li><a>Cañada Chica</a></li>
                                                <li><a>Julián Villagrán</a></li>
                                            </ul>
                                        </div>
                                    </li>
                                    <!--<li><a href="#">Pages</a>
                                        <ul class="dropdown">
                                            <li><a href="index.html">Home</a></li>
                                            <li><a href="about.html">About</a></li>
                                            <li><a href="sermons.html">Sermons</a></li>
                                            <li><a href="sermons-details.html">Sermons Details</a></li>
                                            <li><a href="events.html">Events</a></li>
                                            <li><a href="blog.html">Blog</a></li>
                                            <li><a href="single-post.html">Blog Details</a></li>
                                            <li><a href="contact.html">Contact</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="#">Megamenu</a>
                                        <div class="megamenu">
                                            <ul class="single-mega cn-col-4">
                                                <li><a href="index.html">Home</a></li>
                                                <li><a href="about.html">About</a></li>
                                                <li><a href="sermons.html">Sermons</a></li>
                                                <li><a href="sermons-details.html">Sermons Details</a></li>
                                                <li><a href="events.html">Events</a></li>
                                                <li><a href="blog.html">Blog</a></li>
                                                <li><a href="single-post.html">Blog Details</a></li>
                                                <li><a href="contact.html">Contact</a></li>
                                            </ul>
                                            <ul class="single-mega cn-col-4">
                                                <li><a href="index.html">Home</a></li>
                                                <li><a href="about.html">About</a></li>
                                                <li><a href="sermons.html">Sermons</a></li>
                                                <li><a href="sermons-details.html">Sermons Details</a></li>
                                                <li><a href="events.html">Events</a></li>
                                                <li><a href="blog.html">Blog</a></li>
                                                <li><a href="single-post.html">Blog Details</a></li>
                                                <li><a href="contact.html">Contact</a></li>
                                            </ul>
                                            <ul class="single-mega cn-col-4">
                                                <li><a href="index.html">Home</a></li>
                                                <li><a href="about.html">About</a></li>
                                                <li><a href="sermons.html">Sermons</a></li>
                                                <li><a href="sermons-details.html">Sermons Details</a></li>
                                                <li><a href="events.html">Events</a></li>
                                                <li><a href="blog.html">Blog</a></li>
                                                <li><a href="single-post.html">Blog Details</a></li>
                                                <li><a href="contact.html">Contact</a></li>
                                            </ul>
                                            <ul class="single-mega cn-col-4">
                                                <li><a href="index.html">Home</a></li>
                                                <li><a href="about.html">About</a></li>
                                                <li><a href="sermons.html">Sermons</a></li>
                                                <li><a href="sermons-details.html">Sermons Details</a></li>
                                                <li><a href="events.html">Events</a></li>
                                                <li><a href="blog.html">Blog</a></li>
                                                <li><a href="single-post.html">Blog Details</a></li>
                                                <li><a href="contact.html">Contact</a></li>
                                            </ul>
                                        </div>
                                    </li>
                                    <li><a href="events.html">Events</a></li>
                                    <li><a href="sermons.html">Sermons</a></li>
                                    <li><a href="blog.html">Blog</a></li>
                                    <li><a href="contact.html">Contact</a></li>-->
                                </ul>

                                <!-- Search Button -->
                                <!--<div id="header-search"><i class="fa fa-search" aria-hidden="true"></i></div>-->

                                <!-- Donate Button -->
                                <a href="#" class="btn crose-btn header-btn">Donar</a>

                            </div>
                            <!-- Nav End -->
                        </div>
                    </nav>
                </div>
            </div>

            <!-- ***** Search Form Area ***** -->
            <!--<div class="search-form-area">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-12">
                            <div class="searchForm">
                                <form action="#" method="post">
                                    <input type="search" name="search" id="search" placeholder="Enter keywords &amp; hit enter...">
                                    <button type="submit" class="d-none"></button>
                                </form>
                                <div class="close-icon" id="searchCloseIcon"><i class="fa fa-close" aria-hidden="true"></i></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>-->
        </div>
        <!-- ***** Navbar Area ***** -->
    </header>