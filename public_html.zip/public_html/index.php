<!DOCTYPE html>
<html lang="es">

<head>
    <title>Parroquia de Santiago Apóstol | Inicio</title>
    <?php include 'head.php' ?>
</head>

<body>
    <!-- ##### Preloader ##### -->
    <div class="preloader d-flex align-items-center justify-content-center">
        <!-- Line -->
        <div class="line-preloader"></div>
    </div>

    <!-- ##### Header Area Start ##### -->
        <?php
            include ('header.php');
        ?>
    <!-- ##### Header Area End ##### -->

    <!-- ##### Hero Area Start ##### -->
    <section class="hero-area hero-post-slides owl-carousel">
        <!-- Single Hero Slide -->
        <div class="single-hero-slide bg-img bg-overlay d-flex align-items-center justify-content-center" style="background-image: url(img/bg-img/1.jpg);">
            <!-- Post Content -->
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="hero-slides-content">
                            <h2 data-animation="fadeInUp" data-delay="100ms">Parroquia de Santiago Apóstol</h2>
                            <p data-animation="fadeInUp" data-delay="300ms">La Parroquia es la Familia de los hijos de Dios, es una comunidad de comunidades</p>
                            <a href="#saber_mas" class="btn crose-btn" data-animation="fadeInUp" data-delay="500ms">Saber más</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Single Hero Slide -->
        <!--<div class="single-hero-slide bg-img bg-overlay d-flex align-items-center justify-content-center" style="background-image: url(img/bg-img/2.jpg);">-->
            <!-- Post Content -->
            <!--<div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="hero-slides-content">
                            <h2 data-animation="fadeInUp" data-delay="100ms">Parroquia de Santiago Apóstol</h2>
                            <p data-animation="fadeInUp" data-delay="300ms">La Parroquia es la Familia de los hijos de Dios, es una comunidad de comunidades.</p>
                            <a href="#" class="btn crose-btn" data-animation="fadeInUp" data-delay="500ms">Saber más</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>-->
    </section>
    <!-- ##### Hero Area End ##### -->

    <!-- ##### About Area Start ##### -->
    <section id="saber_mas" class="about-area section-padding-100-0">
        <div class="container">
            <div class="row">
                <!-- Section Heading -->
                <div class="col-12">
                    <div class="section-heading">
                        <h2>Parroquia de Santiago Apóstol</h2>
                        <h2>El Fitzhi, Ixmiquilpan</h2>
                        <h2>Diócesis de Tula</h2>
                        <p>La Parroquia es una determinada comunidad de fieles constituida de modo estable en la Iglesia particular, cuya cura pastoral, bajo la autoridad del Obispo diocesano, se encomienda a un párroco, como su pastar propio (CIC 515).</p>
                    </div>
                </div>
            </div>

            <div class="row about-content justify-content-center">
                <!-- Single About Us Content -->
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="about-us-content mb-100">
                        <img src="img/bg-img/3.jpg" alt="">
                        <div class="about-text">
                            <h4>Oración por nuestra parroquia</h4>
                            <p style="text-align: justify;">¡Dios te bendiga parroquia de Santiago Apóstol!
                            Por los ejemplos de humanidad y de fe de tus gentes...</p>
                            <a href="#" data-toggle="modal" data-target="#modalOracionParroquia">Leer más <i class="fa fa-angle-double-right"></i></a>
                        </div>
                    </div>
                </div>

                <!-- Single About Us Content -->
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="about-us-content mb-100">
                        <img src="img/bg-img/4.jpg" alt="">
                        <div class="about-text">
                            <h4>Mensaje a los fieles</h4>
                            <p style="text-align: justify;">Yo Alejandro, sacerdote párroco, siervo de Cristo Jesús, deseo la gracia y la paz de parte de Dios, nuestro Padre, y del Señor Jesucristo, a todos...</p>
                            <a href="#" data-toggle="modal" data-target="#modalMensaje">Leer más <i class="fa fa-angle-double-right"></i></a>
                        </div>
                    </div>
                </div>

                <!-- Single About Us Content -->
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="about-us-content mb-100">
                        <img src="img/bg-img/5.jpg" alt="">
                        <div class="about-text">
                            <h4>Servicios</h4>
                            <p style="text-align: justify;">Los servicios que brinda esta parroquia incluyen todos los de oficina disponibles para la comunidad, así como la hora santa y confesiones...</p>
                            <a href="#" data-toggle="modal" data-target="#modalServicios">Leer más <i class="fa fa-angle-double-right"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ##### About Area End ##### -->

    <!-- ##### Call To Action Area Start ##### -->
    <!--<section class="call-to-action-area section-padding-100 bg-img bg-overlay" style="background-image: url(img/bg-img/6.jpg)">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="call-to-action-content text-center">
                        <h6>A Place For You</h6>
                        <h2>Find a place to connect and grow through a small group, class, or regular gathering.</h2>
                        <a href="#" class="btn crose-btn btn-2">Become A Member</a>
                    </div>
                </div>
            </div>
        </div>
    </section>-->
    <!-- ##### Call To Action Area End ##### -->

    <!-- ##### Latest Sermons Area Start ##### -->
    <!--<section class="latest-sermons-area section-padding-100-0">
        <div class="container">
            <div class="row">-->
                <!-- Section Heading -->
                <!--<div class="col-12">
                    <div class="section-heading">
                        <h2>Latest Sermons</h2>
                        <p>Loaded with fast-paced worship, activities, and video teachings to address real issues that students face each day</p>
                    </div>
                </div>
            </div>-->

            <!--<div class="row justify-content-center">-->
                <!-- Single Latest Sermons -->
                <!--<div class="col-12 col-md-6 col-lg-4">
                    <div class="single-latest-sermons mb-100">
                        <div class="sermons-thumbnail">
                            <img src="img/bg-img/7.jpg" alt="">-->
                            <!-- Date -->
                            <!--<div class="sermons-date">
                                <h6><span>10</span>MAR</h6>
                            </div>
                        </div>
                        <div class="sermons-content">
                            <div class="sermons-cata">
                                <a href="#" data-toggle="tooltip" data-placement="top" title="Video"><i class="fa fa-video-camera" aria-hidden="true"></i></a>
                                <a href="#" data-toggle="tooltip" data-placement="top" title="Audio"><i class="fa fa-headphones" aria-hidden="true"></i></a>
                                <a href="#" data-toggle="tooltip" data-placement="top" title="Docs"><i class="fa fa-file" aria-hidden="true"></i></a>
                                <a href="#" data-toggle="tooltip" data-placement="top" title="Download"><i class="fa fa-cloud-download" aria-hidden="true"></i></a>
                            </div>
                            <h4>Start a New Way of Living</h4>
                            <div class="sermons-meta-data">
                                <p><i class="fa fa-user" aria-hidden="true"></i> Sermon From: <span>Jorge Malone</span></p>
                                <p><i class="fa fa-tag" aria-hidden="true"></i> Categories: <span>God, Pray</span></p>
                                <p><i class="fa fa-clock-o" aria-hidden="true"></i> March 10 on <span>9:00 am - 11:00 am</span></p>
                            </div>
                        </div>
                    </div>
                </div>-->

                <!-- Single Latest Sermons -->
                <!--<div class="col-12 col-md-6 col-lg-4">
                    <div class="single-latest-sermons mb-100">
                        <div class="sermons-thumbnail">
                            <img src="img/bg-img/8.jpg" alt="">-->
                            <!-- Date -->
                            <!--<div class="sermons-date">
                                <h6><span>11</span>MAY</h6>
                            </div>
                        </div>
                        <div class="sermons-content">
                            <div class="sermons-cata">
                                <a href="#" data-toggle="tooltip" data-placement="top" title="Video"><i class="fa fa-video-camera" aria-hidden="true"></i></a>
                                <a href="#" data-toggle="tooltip" data-placement="top" title="Audio"><i class="fa fa-headphones" aria-hidden="true"></i></a>
                                <a href="#" data-toggle="tooltip" data-placement="top" title="Docs"><i class="fa fa-file" aria-hidden="true"></i></a>
                                <a href="#" data-toggle="tooltip" data-placement="top" title="Download"><i class="fa fa-cloud-download" aria-hidden="true"></i></a>
                            </div>
                            <h4>What Must I Do To Be Save</h4>
                            <div class="sermons-meta-data">
                                <p><i class="fa fa-user" aria-hidden="true"></i> Sermon From: <span>Jorge Malone</span></p>
                                <p><i class="fa fa-tag" aria-hidden="true"></i> Categories: <span>God, Pray</span></p>
                                <p><i class="fa fa-clock-o" aria-hidden="true"></i> March 11 on <span>10:00 am - 11:00 am</span></p>
                            </div>
                        </div>
                    </div>
                </div>-->

                <!-- Single Latest Sermons -->
                <!--<div class="col-12 col-md-6 col-lg-4">
                    <div class="single-latest-sermons mb-100">
                        <div class="sermons-thumbnail">
                            <img src="img/bg-img/9.jpg" alt="">-->
                            <!-- Date -->
                            <!--<div class="sermons-date">
                                <h6><span>15</span>MAY</h6>
                            </div>
                        </div>
                        <div class="sermons-content">
                            <div class="sermons-cata">
                                <a href="#" data-toggle="tooltip" data-placement="top" title="Video"><i class="fa fa-video-camera" aria-hidden="true"></i></a>
                                <a href="#" data-toggle="tooltip" data-placement="top" title="Audio"><i class="fa fa-headphones" aria-hidden="true"></i></a>
                                <a href="#" data-toggle="tooltip" data-placement="top" title="Docs"><i class="fa fa-file" aria-hidden="true"></i></a>
                                <a href="#" data-toggle="tooltip" data-placement="top" title="Download"><i class="fa fa-cloud-download" aria-hidden="true"></i></a>
                            </div>
                            <h4>The Second Coming of Christ</h4>
                            <div class="sermons-meta-data">
                                <p><i class="fa fa-user" aria-hidden="true"></i> Sermon From: <span>Jorge Malone</span></p>
                                <p><i class="fa fa-tag" aria-hidden="true"></i> Categories: <span>God, Pray</span></p>
                                <p><i class="fa fa-clock-o" aria-hidden="true"></i> March 10 on <span>9:00 am - 11:00 am</span></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>-->
    <!-- ##### Latest Sermons Area End ##### -->

    <!-- ##### Upcoming Events Area Start ##### -->
    <!--<section class="upcoming-events-area section-padding-0-100">-->
        <!-- Upcoming Events Heading Area -->
        <!--<div class="upcoming-events-heading bg-img bg-overlay bg-fixed" style="background-image: url(img/bg-img/1.jpg);">
            <div class="container">
                <div class="row">-->
                    <!-- Section Heading -->
                    <!--<div class="col-12">
                        <div class="section-heading text-left white">
                            <h2>Upcoming Events</h2>
                            <p>Be sure to visit our Upcoming Events page regularly to get infomartion</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>-->

        <!-- Upcoming Events Slide -->
        <!--<div class="upcoming-events-slides-area">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="upcoming-slides owl-carousel">

                            <div class="single-slide">-->
                                <!-- Single Upcoming Events Area -->
                                <!--<div class="single-upcoming-events-area d-flex flex-wrap align-items-center">-->
                                    <!-- Thumbnail -->
                                    <!--<div class="upcoming-events-thumbnail">
                                        <img src="img/bg-img/23.jpg" alt="">
                                    </div>-->
                                    <!-- Content -->
                                    <!--<div class="upcoming-events-content d-flex flex-wrap align-items-center">
                                        <div class="events-text">
                                            <h4>Seeing and Savoring Jesus Christ</h4>
                                            <div class="events-meta">
                                                <a href="#"><i class="fa fa-calendar" aria-hidden="true"></i> March 01, 2018</a>
                                                <a href="#"><i class="fa fa-clock-o" aria-hidden="true"></i> 09:00 - 11:00</a>
                                                <a href="#"><i class="fa fa-map-marker" aria-hidden="true"></i> 11 Rose St, Brooklyn, NY</a>
                                            </div>
                                            <p>Join us for an informational webinar about the U.S.-Japan COIL Initiative. Learn about the initiative and receive general guidance.</p>
                                            <a href="#">Leer más <i class="fa fa-angle-double-right"></i></a>
                                        </div>
                                        <div class="find-out-more-btn">
                                            <a href="#" class="btn crose-btn btn-2">Find Out More</a>
                                        </div>
                                    </div>
                                </div>-->

                                <!-- Single Upcoming Events Area -->
                                <!--<div class="single-upcoming-events-area d-flex flex-wrap align-items-center">-->
                                    <!-- Thumbnail -->
                                    <!--<div class="upcoming-events-thumbnail">
                                        <img src="img/bg-img/24.jpg" alt="">
                                    </div>-->
                                    <!-- Content -->
                                    <!--<div class="upcoming-events-content d-flex flex-wrap align-items-center">
                                        <div class="events-text">
                                            <h4>A God-Entranced Vision of All Things</h4>
                                            <div class="events-meta">
                                                <a href="#"><i class="fa fa-calendar" aria-hidden="true"></i> March 15, 2018</a>
                                                <a href="#"><i class="fa fa-clock-o" aria-hidden="true"></i> 11:00 - 13:00</a>
                                                <a href="#"><i class="fa fa-map-marker" aria-hidden="true"></i> 22 Maly St, Matatin, RYO</a>
                                            </div>
                                            <p>Join us for an informational webinar about the U.S.-Japan COIL Initiative. Learn about the initiative and receive general guidance.</p>
                                            <a href="#">Leer más <i class="fa fa-angle-double-right"></i></a>
                                        </div>
                                        <div class="find-out-more-btn">
                                            <a href="#" class="btn crose-btn btn-2">Find Out More</a>
                                        </div>
                                    </div>
                                </div>-->

                                <!-- Single Upcoming Events Area -->
                                <!--<div class="single-upcoming-events-area d-flex flex-wrap align-items-center">-->
                                    <!-- Thumbnail -->
                                    <!--<div class="upcoming-events-thumbnail">
                                        <img src="img/bg-img/25.jpg" alt="">
                                    </div>-->
                                    <!-- Content -->
                                    <!--<div class="upcoming-events-content d-flex flex-wrap align-items-center">
                                        <div class="events-text">
                                            <h4>Speaker Interviews with J.Doe</h4>
                                            <div class="events-meta">
                                                <a href="#"><i class="fa fa-calendar" aria-hidden="true"></i> March 19, 2018</a>
                                                <a href="#"><i class="fa fa-clock-o" aria-hidden="true"></i> 09:00 - 17:00</a>
                                                <a href="#"><i class="fa fa-map-marker" aria-hidden="true"></i> 17 Buit St, Center Disce, LA</a>
                                            </div>
                                            <p>Join us for an informational webinar about the U.S.-Japan COIL Initiative. Learn about the initiative and receive general guidance.</p>
                                            <a href="#">Leer más <i class="fa fa-angle-double-right"></i></a>
                                        </div>
                                        <div class="find-out-more-btn">
                                            <a href="#" class="btn crose-btn btn-2">Find Out More</a>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="single-slide">-->
                                <!-- Single Upcoming Events Area -->
                                <!--<div class="single-upcoming-events-area d-flex flex-wrap align-items-center">-->
                                    <!-- Thumbnail -->
                                    <!--<div class="upcoming-events-thumbnail">
                                        <img src="img/bg-img/23.jpg" alt="">
                                    </div>-->
                                    <!-- Content -->
                                    <!--<div class="upcoming-events-content d-flex flex-wrap align-items-center">
                                        <div class="events-text">
                                            <h4>Seeing and Savoring Jesus Christ</h4>
                                            <div class="events-meta">
                                                <a href="#"><i class="fa fa-calendar" aria-hidden="true"></i> March 01, 2018</a>
                                                <a href="#"><i class="fa fa-clock-o" aria-hidden="true"></i> 09:00 - 11:00</a>
                                                <a href="#"><i class="fa fa-map-marker" aria-hidden="true"></i> 11 Rose St, Brooklyn, NY</a>
                                            </div>
                                            <p>Join us for an informational webinar about the U.S.-Japan COIL Initiative. Learn about the initiative and receive general guidance.</p>
                                            <a href="#">Leer más <i class="fa fa-angle-double-right"></i></a>
                                        </div>
                                        <div class="find-out-more-btn">
                                            <a href="#" class="btn crose-btn btn-2">Find Out More</a>
                                        </div>
                                    </div>
                                </div>-->

                                <!-- Single Upcoming Events Area -->
                                <!--<div class="single-upcoming-events-area d-flex flex-wrap align-items-center">-->
                                    <!-- Thumbnail -->
                                    <!--<div class="upcoming-events-thumbnail">
                                        <img src="img/bg-img/24.jpg" alt="">
                                    </div>-->
                                    <!-- Content -->
                                    <!--<div class="upcoming-events-content d-flex flex-wrap align-items-center">
                                        <div class="events-text">
                                            <h4>A God-Entranced Vision of All Things</h4>
                                            <div class="events-meta">
                                                <a href="#"><i class="fa fa-calendar" aria-hidden="true"></i> March 15, 2018</a>
                                                <a href="#"><i class="fa fa-clock-o" aria-hidden="true"></i> 11:00 - 13:00</a>
                                                <a href="#"><i class="fa fa-map-marker" aria-hidden="true"></i> 22 Maly St, Matatin, RYO</a>
                                            </div>
                                            <p>Join us for an informational webinar about the U.S.-Japan COIL Initiative. Learn about the initiative and receive general guidance.</p>
                                            <a href="#">Leer más <i class="fa fa-angle-double-right"></i></a>
                                        </div>
                                        <div class="find-out-more-btn">
                                            <a href="#" class="btn crose-btn btn-2">Find Out More</a>
                                        </div>
                                    </div>
                                </div>-->

                                <!-- Single Upcoming Events Area -->
                                <!--<div class="single-upcoming-events-area d-flex flex-wrap align-items-center">-->
                                    <!-- Thumbnail -->
                                    <!--<div class="upcoming-events-thumbnail">
                                        <img src="img/bg-img/25.jpg" alt="">
                                    </div>-->
                                    <!-- Content -->
                                    <!--<div class"upcoming-events-content d-flex flex-wrap align-items-center">
                                        <div class="events-text">
                                            <h4>Speaker Interviews with J.Doe</h4>
                                            <div class="events-meta">
                                                <a href="#"><i class="fa fa-calendar" aria-hidden="true"></i> March 19, 2018</a>
                                                <a href="#"><i class="fa fa-clock-o" aria-hidden="true"></i> 09:00 - 17:00</a>
                                                <a href="#"><i class="fa fa-map-marker" aria-hidden="true"></i> 17 Buit St, Center Disce, LA</a>
                                            </div>
                                            <p>Join us for an informational webinar about the U.S.-Japan COIL Initiative. Learn about the initiative and receive general guidance.</p>
                                            <a href="#">Leer más <i class="fa fa-angle-double-right"></i></a>
                                        </div>
                                        <div class="find-out-more-btn">
                                            <a href="#" class="btn crose-btn btn-2">Find Out More</a>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>-->
    <!-- ##### Upcoming Events Area End ##### -->

    <!-- ##### Gallery Area Start ##### -->
    <div id="galeria" class="gallery-area d-flex flex-wrap">
        <!-- Single Gallery Area -->
        <div class="single-gallery-area">
            <a href="img/bg-img/13.jpg" class="gallery-img" title="Gallery Image 1">
                <img src="img/bg-img/13.jpg" alt="">
            </a>
        </div>

        <!-- Single Gallery Area -->
        <div class="single-gallery-area">
            <a href="img/bg-img/14.jpg" class="gallery-img" title="Gallery Image 2">
                <img src="img/bg-img/14.jpg" alt="">
            </a>
        </div>

        <!-- Single Gallery Area -->
        <div class="single-gallery-area">
            <a href="img/bg-img/15.jpg" class="gallery-img" title="Gallery Image 3">
                <img src="img/bg-img/15.jpg" alt="">
            </a>
        </div>

        <!-- Single Gallery Area -->
        <div class="single-gallery-area">
            <a href="img/bg-img/16.jpg" class="gallery-img" title="Gallery Image 4">
                <img src="img/bg-img/16.jpg" alt="">
            </a>
        </div>

        <!-- Single Gallery Area -->
        <div class="single-gallery-area">
            <a href="img/bg-img/17.jpg" class="gallery-img" title="Gallery Image 5">
                <img src="img/bg-img/17.jpg" alt="">
            </a>
        </div>

        <!-- Single Gallery Area -->
        <div class="single-gallery-area">
            <a href="img/bg-img/18.jpg" class="gallery-img" title="Gallery Image 6">
                <img src="img/bg-img/18.jpg" alt="">
            </a>
        </div>

        <!-- Single Gallery Area -->
        <div class="single-gallery-area">
            <a href="img/bg-img/19.jpg" class="gallery-img" title="Gallery Image 7">
                <img src="img/bg-img/19.jpg" alt="">
            </a>
        </div>

        <!-- Single Gallery Area -->
        <div class="single-gallery-area">
            <a href="img/bg-img/20.jpg" class="gallery-img" title="Gallery Image 8">
                <img src="img/bg-img/20.jpg" alt="">
            </a>
        </div>

        <!-- Single Gallery Area -->
        <div class="single-gallery-area">
            <a href="img/bg-img/21.jpg" class="gallery-img" title="Gallery Image 9">
                <img src="img/bg-img/21.jpg" alt="">
            </a>
        </div>

        <!-- Single Gallery Area -->
        <div class="single-gallery-area">
            <a href="img/bg-img/22.jpg" class="gallery-img" title="Gallery Image 10">
                <img src="img/bg-img/22.jpg" alt="">
            </a>
        </div>
    </div>
    <!-- ##### Gallery Area End ##### -->

    <!-- ##### Blog Area Start ##### -->
    <section id="anuncios" class="blog-area section-padding-100-0">
        <div class="container">
            <div class="row">
                <!-- Section Heading -->
                <div class="col-12">
                    <div class="section-heading">
                        <h2>Últimos anuncios</h2>
                        <p>Últimos anuncios, agregados por nuestros pastorales</p>
                    </div>
                </div>
            </div>

            <div class="row justify-content-center">
                <!-- Single Blog Post Area -->
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="single-blog-post mb-100">
                        <div class="post-thumbnail">
                            <a href="single-post.html"><img src="img/bg-img/10.jpg" alt=""></a>
                        </div>
                        <div class="post-content">
                            <a href="single-post.html" class="post-title">
                                <h4>Anuncio 1</h4>
                            </a>
                            <div class="post-meta d-flex">
                                <a href="#"><i class="fa fa-user" aria-hidden="true"></i> Pastoral 1</a>
                                <a href="#"><i class="fa fa-calendar" aria-hidden="true"></i> 15/10/20</a>
                            </div>
                            <p class="post-excerpt">Este es un ejemplo de anuncio, el cual se agregará por los pastorales autorizados para ello, con su respectiva imagen.</p>
                        </div>
                    </div>
                </div>

                <!-- Single Blog Post Area -->
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="single-blog-post mb-100">
                        <div class="post-thumbnail">
                            <a href="single-post.html"><img src="img/bg-img/11.jpg" alt=""></a>
                        </div>
                        <div class="post-content">
                            <a href="single-post.html" class="post-title">
                                <h4>Anuncio 2</h4>
                            </a>
                            <div class="post-meta d-flex">
                                <a href="#"><i class="fa fa-user" aria-hidden="true"></i> Pastoral 2</a>
                                <a href="#"><i class="fa fa-calendar" aria-hidden="true"></i> 16/10/20</a>
                            </div>
                            <p class="post-excerpt">Este es un ejemplo de anuncio, el cual se agregará por los pastorales autorizados para ello, con su respectiva imagen.</p>
                        </div>
                    </div>
                </div>

                <!-- Single Blog Post Area -->
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="single-blog-post mb-100">
                        <div class="post-thumbnail">
                            <a href="single-post.html"><img src="img/bg-img/12.jpg" alt=""></a>
                        </div>
                        <div class="post-content">
                            <a href="single-post.html" class="post-title">
                                <h4>Anuncio 3</h4>
                            </a>
                            <div class="post-meta d-flex">
                                <a href="#"><i class="fa fa-user" aria-hidden="true"></i> Pastoral 3</a>
                                <a href="#"><i class="fa fa-calendar" aria-hidden="true"></i> 17/10/20</a>
                            </div>
                            <p class="post-excerpt">Este es un ejemplo de anuncio, el cual se agregará por los pastorales autorizados para ello, con su respectiva imagen.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ##### Blog Area End ##### -->

    <!-- ##### Subscribe Area Start ##### -->
    <?php include 'subscribe-area.php' ?>
    <!-- ##### Subscribe Area End ##### -->

    <!-- ##### Footer Area Start ##### -->
    <?php include 'footer.php' ?>
    <!-- ##### Footer Area End ##### -->
    
    <!-- ##### Inicio de Modales ##### -->
    
    <!-- Modal Objetivos generales -->
    <div class="modal fade" id="modalOracionParroquia" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    	<div class="modal-dialog" role="document">
    		<div class="modal-content">
    			<div class="modal-header">
    				<h4 style="text-align: left;" class="modal-title" id="myModalLabel">Oración por nuestra parroquia</h4>
    				<button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
    					<span aria-hidden="true">&times;</span>
    				</button>
    			</div>
    			<div style="text-align: justify;" class="modal-body">
    			    <img src="img/bg-img/3.jpg" alt="">
    				<br></br>
    				¡Dios te bendiga parroquia de Santiago Apóstol!
    				<br></br>
                    Por los ejemplos de humanidad y de fe de tus gentes, por los esfuerzos en mantener unida la Familia.
                    <br></br>
                    ¡Dios te bendiga parroquia de Santiago Apóstol!
                    <br></br>
                    Por la fidelidad y amor de tus hijos a la Iglesia, hijos de un mismo Padre.
                    <br></br>
                    ¡Dios te bendiga parroquia de Santiago Apóstol!
                    <br></br>
                    Que cuentas con pueblos indígenas, cuyo progreso y respeto quieres promover. Ellos conservan ricos valores humanos y religiosos y quieren trabajar juntos en la construcción del Reino de Dios.
                    <br></br>
                    ¡Dios te bendiga parroquia de Santiago Apóstol!
                    <br></br>
                    Que te esfuerzas en desterrar para siempre las luchas que dividieron a tus hijos. 
                    <br></br>
                    ¡Dios te bendiga parroquia de Santiago Apóstol!
                    <br></br>
                    Que sigues extrañando a tus hijos emigrantes en busca de pan y trabajo.
                    <br></br>
                    ¡Dios te bendiga parroquia de Santiago Apóstol!
                    <br></br>
                    Por  las comunidades eclesiales de una cultura cristiana.
                    <br></br>
                    ¡Dios te bendiga parroquia de Santiago Apóstol!
                    <br></br>
                    ¡Vela por nuestra parroquia!
                    <br></br>
                    ¡Vela por nuestra parroquia!
                    <br></br>
                    ¡Dios te bendiga parroquia de Santiago Apóstol!
    			</div>
    		</div>
    	</div>
	</div>
	
	<!-- Modal Quienes integran -->
	<div class="modal fade" id="modalMensaje" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h4 style="text-align: left;" class="modal-title" id="myModalLabel">Mensaje a los fieles</h4>
				<button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div style="text-align: justify;" class="modal-body">
			    <img src="img/bg-img/4.jpg" alt="">
				<br></br>
				Yo Alejandro, sacerdote párroco, siervo de Cristo Jesús, deseo la gracia y la paz de parte de Dios, nuestro Padre, y del Señor Jesucristo, a todos los hermanos en Cristo Jesús, que forman esta Parroquia, a todos sus fieles, autoridades religiosas y civiles.
				<br></br>
                Le doy gracias a Dios que nos ha llamado al conocimiento de su Palabra, a la fe y la esperanza en su hijo amado, Jesucristo Camino, Verdad y Vida.
                <br></br>
                Con gran alegría ofrecemos al Señor este medio de la página WEB de nuestra Parroquia amada de Santiago Apóstol, con el fin de seguir creciendo en la difusión del Evangelio, para que sean más los que lo conozcan, lo amen y lo sigan.
                <br></br>
                Nuestra meta es ser continuadores de la obra de Salvación que Jesucristo inauguró con su Pascua, en esta nueva cultura marcada por los avances tecnológicos y la globalización. Llegando a ser sus Discípulos y Misioneros, en la alegría, en la hermandad y en la comunión.
                <br></br>
                En esta página se podrá encontrar la información más relevante de la vida de nuestra Parroquia. Sobre los trabajos de evangelización, los servicios, la celebración de los sacramentos, así como datos sobre la vida de fe de nuestros pueblos. Nuestro objetivo es facilitar, con la mejor eficiencia, los servicios que se ofrecen en nuestra Parroquia de Santiago Apóstol.
                <br></br>
                Que Dios, nuestro Padre se digne bendecir este nuevo proyecto que ponemos en sus manos, y que María Santísima de Guadalupe nos siga alentando con su amor de madre, en nuestro seguimiento de su Hijo amado Jesucristo.
			</div>
		</div>
	</div>
	</div>
	
	<!-- Modal Misión -->
	<div class="modal fade" id="modalServicios" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h4 style="text-align: left;" class="modal-title" id="myModalLabel">Servicios</h4>
				<button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div style="text-align: justify;" class="modal-body">
			    <img src="img/bg-img/5.jpg" alt="">
				<br></br>
				<p><b>Oficina:</b> La oficina ofrece sus servicios a toda la comunidad en los siguientes horarios:</p>
			    <li style="padding-left: 20px; color: #636363;">Martes, jueves y viernes: 14:00 hrs. a 19:00 hrs.</li>
			    <li style="padding-left: 20px; color: #636363;">Domingos: 9:00 hrs. a 14:00 hrs.</li>
			    <p style="padding-top: 10px; padding-bottom: 5px;"><b>Hora Santa:</b> Jueves a las 18:00 hrs.</p>
			    <p style="padding-top: 0px;"><b>Confesiones:</b> Jueves, de 18:00 hrs. a 19:00 hrs.</p>
			</div>
		</div>
	</div>
	</div>
	
	<!-- Modal Visión -->
	<div class="modal fade" id="modalVision" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h4 style="text-align: left;" class="modal-title" id="myModalLabel">Visión</h4>
				<button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div style="text-align: justify;" class="modal-body">
			    <img src="img/bg-img/Vision.jpg" alt="">
				<br></br>
				Construir el reino de Dios desde las familias, de modo que ellas se anuncien, se celebre y sirva el evangelio del matrimonio, la familia y la vida y sean las familias, fermento de vida cristiana en su ciudad.
			</div>
		</div>
	</div>
	</div>
	
	<!-- Modal Valores -->
	<div class="modal fade" id="modalValores" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h4 style="text-align: left;" class="modal-title" id="myModalLabel">Valores</h4>
				<button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div style="text-align: justify;" class="modal-body">
			    <img src="img/bg-img/Valores.jpg" alt="" style="width: 466px;">
				<br></br>
				En el movimiento familiar cristiano creemos que la familia lleva consigo el porvenir de la persona y de la sociedad y que dicho porvenir se va fraguando día a día desde los valores evangélicos.
				<br></br>
Estamos convencido que quien vive en la fe el valor de la familia ejercita valores como (la generosidad, la sinceridad, la alegría, la cordialidad, la aceptación, la comunidad, el respeto, la responsabilidad, la compasión, la lealtad, la confianza, la paz, la seguridad, etc.) y por medio de ella se forjan las personas. Creemos que el valor fundamental de la familia radica en el hecho de que Dios creador es quien dio origen al matrimonio y la familia.
			</div>
		</div>
	</div>
	</div>
	
	<!-- Modal Lugar de reunión -->
	<div class="modal fade" id="modalLugarReunion" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h4 style="text-align: left;" class="modal-title" id="myModalLabel">Lugar de reunión</h4>
				<button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div style="text-align: justify;" class="modal-body">
			    <img src="img/bg-img/Lugar_reunion.jpg" alt="">
				<br></br>
				En los salones de la parroquia, en casa del matrimonio, pero por la pandemia las reuniones son por medio de (ZOOM O VIDEOLLAMADA) por decir de algún medio digital. Las reuniones son cada (8 días) después de terminar sus actividades cotidianas.
			</div>
		</div>
	</div>
	</div>
    
    <!-- ##### Fin de Modales ##### -->

    <!-- ##### All Javascript Script ##### -->
    <!-- jQuery-2.2.4 js -->
    <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="js/bootstrap/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="js/bootstrap/bootstrap.min.js"></script>
    <!-- All Plugins js -->
    <script src="js/plugins/plugins.js"></script>
    <!-- Active js -->
    <script src="js/active.js"></script>
</body>

</html>