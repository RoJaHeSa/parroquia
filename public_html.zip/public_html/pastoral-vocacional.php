<!DOCTYPE html>
<html lang="es">

<head>
    <title>Parroquia de Santiago Apóstol | Pastoral vocacional</title>
    <?php include 'head.php' ?>
</head>

<body>
    <!-- ##### Preloader ##### -->
    <div class="preloader d-flex align-items-center justify-content-center">
        <!-- Line -->
        <div class="line-preloader"></div>
    </div>

    <!-- ##### Header Area Start ##### -->
        <?php include 'header.php'; ?>
    <!-- ##### Header Area End ##### -->

    <!-- ##### Breadcrumb Area Start ##### -->
    <div class="breadcrumb-area">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="index.php">Inicio</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Vocacional</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <!-- ##### Breadcrumb Area End ##### -->

    <!-- ##### About Us Area Start ##### -->
    <div class="about-us-area about-page section-padding-100">
        <div class="container">
            <div class="row align-items-center justify-content-between">
                <div class="col-12 col-lg-5">
                    <div class="about-content">
                        <h2>Pastoral vocacional</h2>
                        <p style="text-align: justify;">Buscamos impulsar la pastoral vocacional desde el encuentro personal y comunitario con Cristo, para que en comunión con la Pastoral Diocesana, cada bautizado descubra y viva su vocación específica, como discípulo y misionero de Cristo.</p>
                        <div class="opening-hours-location mt-30 d-flex align-items-center">
                            <!-- Botón de integrantes -->
                            <div class="opening-hours">
                                <!--<h6><i class="fa fa-clock-o"></i> Opening Hours</h6>
                                <p>Mon - Fri at 08:00 - 21:00 <br>Sunday at 09:00 - 18:00</p>-->
                                <button data-toggle="modal" data-target="#modalIntegrantes" class="btn crose-btn btn-lg btn-block"><i class="fa fa-user-o"></i> Integrantes</button>
                            </div>
                            <!-- Botón de misión -->
                            <div class="opening-hours">
                                <!--<h6><i class="fa fa-map-marker"></i> Location</h6>
                                <p>No 40 Baria Sreet 133/2 NewYork City, NY, United States</p>-->
                                <button data-toggle="modal" data-target="#modalMision" class="btn crose-btn btn-lg btn-block"><i class="fa fa-line-chart"></i> Misión</button>
                            </div>
                        </div>
                        <div class="opening-hours-location mt-30 d-flex align-items-center">
                            <!-- Botón de visión -->
                            <div class="opening-hours">
                                <!--<h6><i class="fa fa-clock-o"></i> Opening Hours</h6>
                                <p>Mon - Fri at 08:00 - 21:00 <br>Sunday at 09:00 - 18:00</p>-->
                                <button data-toggle="modal" data-target="#modalLogros" class="btn crose-btn btn-lg btn-block"><i class="fa fa-trophy"></i> Logros</button>
                            </div>
                            <!-- Botón de valores -->
                            <div class="opening-hours">
                                <!--<h6><i class="fa fa-map-marker"></i> Location</h6>
                                <p>No 40 Baria Sreet 133/2 NewYork City, NY, United States</p>-->
                                <button data-toggle="modal" data-target="#modalValores" class="btn crose-btn btn-lg btn-block"><i class="fa fa-handshake-o"></i> Valores</button>
                            </div>
                        </div>
                        <div class="opening-hours-location mt-30 d-flex align-items-center">
                            <div class="opening-hours">
                                <button data-toggle="modal" data-target="#modalInformes" class="btn crose-btn btn-lg btn-block"><i class="fa fa-question-circle"></i> Informes</button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-lg-6">
                    <div class="about-thumbnail">
                        <img src="img/bg-img/pastoral-vocacional/1.jpg" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ##### About Us Area End ##### -->

    <!-- #### Modales #### -->
    <!-- Modal Integrantes -->
    <div class="modal fade" id="modalIntegrantes" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    	<div class="modal-dialog" role="document">
    		<div class="modal-content">
    			<div class="modal-header">
    				<h4 style="text-align: left;" class="modal-title" id="myModalLabel">Integrantes</h4>
    				<button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
    					<span aria-hidden="true">&times;</span>
    				</button>
    			</div>
    			<div style="text-align: justify;" class="modal-body">
    			    <img src="img/bg-img/pastoral-vocacional/2.jpg" alt="">
    				<br></br>
    				Este pastoral está conformado por María Luisa Cipriano, Marina Falcón Benítez y Margarita Silva Hernández.

    			</div>
    		</div>
    	</div>
	</div>
	
	<!-- Modal Misión -->
	<div class="modal fade" id="modalMision" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    	<div class="modal-dialog" role="document">
    		<div class="modal-content">
    			<div class="modal-header">
    				<h4 style="text-align: left;" class="modal-title" id="myModalLabel">Misión</h4>
    				<button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
    					<span aria-hidden="true">&times;</span>
    				</button>
    			</div>
    			<div style="text-align: justify;" class="modal-body">
    			    <img src="img/bg-img/pastoral-vocacional/3.jpg" alt="">
    				<br></br>
    				Una más de las misiones de la Pastoral es hacer conciencia en las familias de la ayuda que debemos brindar a la casa de formación de los futuros sacerdotes (seminario) con el apoyo en especie, en cada Hora Santa Vocacional se recogen los productos básicos que formarán una despensa la cual es llevada por nuestro sacerdote.
    				<br></br>
                    También anualmente participamos en la organización y el desarrollo de dos encuentros con jóvenes, donde les ayudamos a descubrir la Vocación específica que Dios les ha designado.

    			</div>
    		</div>
    	</div>
	</div>
	
	<!-- Modal Visión -->
	<div class="modal fade" id="modalInformes" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    	<div class="modal-dialog" role="document">
    		<div class="modal-content">
    			<div class="modal-header">
    				<h4 style="text-align: left;" class="modal-title" id="myModalLabel">Informes</h4>
    				<button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
    					<span aria-hidden="true">&times;</span>
    				</button>
    			</div>
    			<div style="text-align: justify;" class="modal-body">
    			    <!--<img src="img/bg-img/pastoral-familiar/4.jpg" alt="">
    				<br></br>-->
    				Para ofrecer una información más detallada de este servicio puedes comunicarte con la coordinadora Margarita Silva Hernández a los números 772 132 3112 y 759 72 3 4418.
    			</div>
    		</div>
    	</div>
	</div>
	
	<!-- Modal Valores -->
	<div class="modal fade" id="modalValores" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    	<div class="modal-dialog" role="document">
    		<div class="modal-content">
    			<div class="modal-header">
    				<h4 style="text-align: left;" class="modal-title" id="myModalLabel">Valores</h4>
    				<button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
    					<span aria-hidden="true">&times;</span>
    				</button>
    			</div>
    			<div style="text-align: justify;" class="modal-body">
    			    <img src="img/bg-img/pastoral-vocacional/5.jpg" alt="">
    				<br></br>
    				Se fomenta la oración en familia con la Cruz Vocacional, la cual permanece una semana en su hogar, se reúnen y hacen oración con el material que se les proporciona, próximamente será de manera virtual, y la oración se hace por todas las vocaciones, pero principalmente se hace por la familia que es la iglesia doméstica donde surgen todas las Vocaciones. 
    			</div>
    		</div>
    	</div>
	</div>
	
	<!-- Modal Lugar -->
	<div class="modal fade" id="modalLogros" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    	<div class="modal-dialog" role="document">
    		<div class="modal-content">
    			<div class="modal-header">
    				<h4 style="text-align: left;" class="modal-title" id="myModalLabel">Logros</h4>
    				<button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
    					<span aria-hidden="true">&times;</span>
    				</button>
    			</div>
    			<div style="text-align: justify;" class="modal-body">
    			    <img src="img/bg-img/pastoral-vocacional/4.jpg" alt="">
    				<br></br>
    				Entre los logros que hemos alcanzado en este caminar se encuentra el interés de las familias, que han abiertos su corazón, por la oración Vocacional, ya que a través del encuentro con nuestro Señor han valorado la importancia y la necesidad de esta comunicación permanente con nuestro Creador.
    				<br></br>
                    Todo esto ha sido posible por el acompañamiento de nuestro párroco y el trabajo de los integrantes de la pastora, la cual está en la espera de elementos que permitan fortalecer este apostolado.
    			</div>
    		</div>
    	</div>
	</div>
	
	<!-- ##### Fin del área de modales ##### -->

    <!-- ##### Subscribe Area Start ##### -->
    <?php include 'subscribe-area.php' ?>
    <!-- ##### Subscribe Area End ##### -->

    <!-- ##### Footer Area Start ##### -->
    <?php include 'footer.php' ?>
    <!-- ##### Footer Area End ##### -->

    <!-- ##### All Javascript Script ##### -->
    <!-- jQuery-2.2.4 js -->
    <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="js/bootstrap/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="js/bootstrap/bootstrap.min.js"></script>
    <!-- All Plugins js -->
    <script src="js/plugins/plugins.js"></script>
    <!-- Active js -->
    <script src="js/active.js"></script>
</body>

</html>