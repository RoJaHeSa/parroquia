<!DOCTYPE html>
<html lang="es">

<head>
    <title>Parroquia de Santiago Apóstol | Pastoral profética</title>
    <?php include 'head.php' ?>
</head>

<body>
    <!-- ##### Preloader ##### -->
    <div class="preloader d-flex align-items-center justify-content-center">
        <!-- Line -->
        <div class="line-preloader"></div>
    </div>

    <!-- ##### Header Area Start ##### -->
        <?php include 'header.php'; ?>
    <!-- ##### Header Area End ##### -->

    <!-- ##### Breadcrumb Area Start ##### -->
    <div class="breadcrumb-area">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="index.php">Inicio</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Profética</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <!-- ##### Breadcrumb Area End ##### -->

    <!-- ##### About Us Area Start ##### -->
    <div class="about-us-area about-page section-padding-100">
        <div class="container">
            <div class="row align-items-center justify-content-between">
                <div class="col-12 col-lg-5">
                    <div class="about-content">
                        <h2>Pastoral profética</h2>
                        <p style="text-align: justify;">Buscamos recomenzar desde  Cristo siguiendo el itinerario que el señor vivió con sus discípulos: Desde un  Encuentro personal con Jesucristo, Vivencia comunitaria, Formación Bíblico-Teológica, para un Compromiso misionero, para revitalizar la comunidad, en actitud de conversión personal y pastoral, como discípulo misionero, al servicio de su Reino de Vida.
                        </p>
                        <div class="opening-hours-location mt-30 d-flex align-items-center">
                            <!-- Botón de integrantes -->
                            <div class="opening-hours">
                                <!--<h6><i class="fa fa-clock-o"></i> Opening Hours</h6>
                                <p>Mon - Fri at 08:00 - 21:00 <br>Sunday at 09:00 - 18:00</p>-->
                                <button data-toggle="modal" data-target="#modalIntegrantes" class="btn crose-btn btn-lg btn-block"><i class="fa fa-user-o"></i> Integrantes</button>
                            </div>
                            <!-- Botón de misión -->
                            <div class="opening-hours">
                                <!--<h6><i class="fa fa-map-marker"></i> Location</h6>
                                <p>No 40 Baria Sreet 133/2 NewYork City, NY, United States</p>-->
                                <button data-toggle="modal" data-target="#modalObjetivo" class="btn crose-btn btn-lg btn-block"><i class="fa fa-line-chart"></i> Objetivo</button>
                            </div>
                        </div>
                        <div class="opening-hours-location mt-30 d-flex align-items-center">
                            <!-- Botón de visión -->
                            <div class="opening-hours">
                                <!--<h6><i class="fa fa-clock-o"></i> Opening Hours</h6>
                                <p>Mon - Fri at 08:00 - 21:00 <br>Sunday at 09:00 - 18:00</p>-->
                                <button data-toggle="modal" data-target="#modalPresentacion" class="btn crose-btn btn-lg btn-block"><i class="fa fa-file-text"></i> Presentación</button>
                            </div>
                            <!-- Botón de valores -->
                            <div class="opening-hours">
                                <!--<h6><i class="fa fa-map-marker"></i> Location</h6>
                                <p>No 40 Baria Sreet 133/2 NewYork City, NY, United States</p>-->
                                <button data-toggle="modal" data-target="#modalLogros" class="btn crose-btn btn-lg btn-block"><i class="fa fa-trophy"></i> Logros</button>
                            </div>
                        </div>
                        <div class="opening-hours-location mt-30 d-flex align-items-center">
                            <div class="opening-hours">
                                <button data-toggle="modal" data-target="#modalResponsables" class="btn crose-btn btn-lg btn-block"><i class="fa fa-exclamation-circle"></i> Responsables</button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-lg-6">
                    <div class="about-thumbnail">
                        <img src="img/bg-img/pastoral-profetica/1.jpg" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ##### About Us Area End ##### -->

    <!-- #### Modales #### -->
    <!-- Modal Integrantes -->
    <div class="modal fade" id="modalIntegrantes" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    	<div class="modal-dialog" role="document">
    		<div class="modal-content">
    			<div class="modal-header">
    				<h4 style="text-align: left;" class="modal-title" id="myModalLabel">Quienes integran</h4>
    				<button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
    					<span aria-hidden="true">&times;</span>
    				</button>
    			</div>
    			<div style="text-align: justify;" class="modal-body">
    			    <img src="img/bg-img/pastoral-profetica/2.jpg" alt="">
    				<br></br>
    				<p>Esta pastoral está formada por 4 áreas.</p>
                	<p style="margin-left: 20px;">a.- PREBAUTISMALES</p>
                	<p style="margin-left: 20px;">b.- ESCUELA PARA PADRES DE ESCUELA DE CATEQUESIS</p>
                	<p style="margin-left: 20px;">C.- FORMACION DE CATEQUISTAS Y PAPAS.</p>
                	<p style="margin-left: 20px;">d.- ESCUELAS DE CATEQUESIS ESCOLARIZADA.</p>
    			</div>
    		</div>
    	</div>
	</div>
	
	<!-- Modal Misión -->
	<div class="modal fade" id="modalObjetivo" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    	<div class="modal-dialog" role="document">
    		<div class="modal-content">
    			<div class="modal-header">
    				<h4 style="text-align: left;" class="modal-title" id="myModalLabel">Objetivo específico</h4>
    				<button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
    					<span aria-hidden="true">&times;</span>
    				</button>
    			</div>
    			<div style="text-align: justify;" class="modal-body">
    			    <img src="img/bg-img/pastoral-profetica/3.jpg" alt="">
    				<br></br>
    				Propiciar el conocimiento de la fe, la educación litúrgica, la formación moral, la educación a la oración, la educación para la vida comunitaria y la iniciación a la misión de servir para crecer como personas creyentes desde el núcleo familiar
    			</div>
    		</div>
    	</div>
	</div>
	
	<!-- Modal Visión -->
	<div class="modal fade" id="modalPresentacion" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    	<div class="modal-lg modal-dialog" role="document">
    		<div class="modal-content">
    			<div class="modal-header">
    				<h4 style="text-align: left;" class="modal-title" id="myModalLabel">Carta de presentación</h4>
    				<button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
    					<span aria-hidden="true">&times;</span>
    				</button>
    			</div>
    			<div style="text-align: justify;" class="modal-body">
    			    <!--<img src="img/bg-img/pastoral-familiar/4.jpg" alt="">
    				<br></br>-->
    				<p>
    				    <b>a.- Que hace.</b> Podemos decir que está pastoral  trabaja para facilitar el conocimiento y la profundización de los contenidos     sacramentales de la iniciación cristiana, formular una síntesis de fe y dar razón de lo que se cree, se espera y se ama, facilitando el conocimiento,  la interiorización a la vivencia de los valores para  formar un compromiso misionero más  que  un requisito sacramental por tradición sede por  convicción.
				    </p>
				    <p>
                        <b>b.- Cada cuando se reúnen:</b>   Aquí cada área, tiene su día y hora.
                    </p>
                    <p style="padding-left: 20px;">
                        	•	PREBAUTISMALES.  Se dan pláticas 4 días a la semana de 6:00 pm a 8:00 pm, en las instalaciones de la parroquia.
                        	<br></br>
                        	•	ESCUELA PARA PADRES.  Se dan pláticas 5 días una vez al mes, en cada una de las comunidades que conforman la parroquia, en base a un calendario, todas las pláticas son de 5:00 pm a 7:00 pm, conformada por 2 niveles. Siendo el primer nivel para los papas que sus hijos van a realizar COMUNION y el segundo nivel, para papas de sus hijos que harán CONFIRMACION. También se invita a los padrinos.
                        	<br></br>
                        	•	FORMACION : Esta área se divide en 2.  LA PRIMERA PARTE.  Se tiene formación por parte del Párroco,  como por el quipo de Formación a catequistas
                        	<br></br>
                        	<img src="img/bg-img/pastoral-profetica/4.png" alt="">
                        	<br></br>
                        	•	ESCUELA DE CATEQUESIS ESCOLARIZADA:   Esta es la 4 área de la pastoral profética, y podemos decir que la más activa, pues es aquí donde se trabaja con los niños en formación, cuyas edades varían desde los   7 años hasta 99 años, trabajando Principalmente en los Sacramentos de Eucaristía y Confirmación.   Manejando cada año, un promedio de 1,000 niños y   se cuenta con un promedio de 100 catequistas, a nivel parroquial, para poder atenderlos en sus diferentes niveles
                	</p>
    			</div>
    		</div>
    	</div>
	</div>
	
	<!-- Modal Valores -->
	<div class="modal fade" id="modalLogros" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    	<div class="modal-dialog" role="document">
    		<div class="modal-content">
    			<div class="modal-header">
    				<h4 style="text-align: left;" class="modal-title" id="myModalLabel">Logros</h4>
    				<button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
    					<span aria-hidden="true">&times;</span>
    				</button>
    			</div>
    			<div style="text-align: justify;" class="modal-body">
    			    <img src="img/bg-img/pastoral-profetica/5.jpg" alt="">
    				<br></br>
    				A nivel general de la pastoral, podemos decir que el principal logro, es haber  establecido el sistema  escolarizado,  manejando  en todas sus comunidades 4 años de formación como mínimo,  y en varias se han abierto todos los niveles,  desde primero  y   nos da la  oportunidad de ir enseñando de manera  ordenada  el sistema que se maneja  basado en la Santísima Trinidad, Pues en el primer y segundo año, se conoce al PADRE,  en tercer y cuarto nivel,  se ve al HIJO  y es cuando realizan la PRIMERA COMUNION y durante quinto y sexto nivel se ve al ESPIRITU SANTO y realizan la CONFIRMACION ,  además de vivir durante el año cada una de las tradiciones, celebraciones y festividades de  nuestra religión  explicándoles el cómo y por qué de las mismas,  aparte de hacerlos participes de ellas.
    				<br></br>
                    También, podemos manejar como logros el que en todas las comunidades se haya   establecido formación para los papas que una vez concluida su preparación realizan sus sacramentos, muchos junto con sus hijos y de esta manera también apoyarlos en conocer un poco más de su Religión, y ayudarlos a fomentar un poco más su fe, pues tristemente la mayoría de papas, venimos de un hogar católico, pero sin formación de fe, sino más bien tradicionalista. Eso nos lleva a vivir nuestra fe desde un punto de   vista, meramente sacramental y dominical por herencia de nuestros padres, que por una verdadera fe.
    			</div>
    		</div>
    	</div>
	</div>
	
	<!-- Modal Lugar -->
	<div class="modal fade" id="modalResponsables" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    	<div class="modal-lg modal-dialog" role="document">
    		<div class="modal-content">
    			<div class="modal-header">
    				<h4 style="text-align: left;" class="modal-title" id="myModalLabel">Responsables</h4>
    				<button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
    					<span aria-hidden="true">&times;</span>
    				</button>
    			</div>
    			<div style="text-align: justify;" class="modal-body">
    			    <!--<img src="img/bg-img/pastoral-profetica/6.jpg" alt="">
    				<br></br>-->
    				<table class="table table-striped">
    				    <thead>
    				        <tr>
    				            <th>Área</th>
    				            <th>Responsable</th>
    				            <th>Teléfono</th>
    				            <th>Correo</th>
    				        </tr>
    				    </thead>
    				    <tbody>
    				        <tr>
    				            <th>Prebautismales</th>
    				            <td>Ana María Moreno Ángeles y Vladimir</td>
    				            <td>Cel. 7721288378</td>
    				            <td>nava_5355@hotmail.com</td>
    				        </tr>
    				        <tr>
    				            <th>Escuela para padres</th>
    				            <td>Ana María Moreno Ángeles y Vladimir</td>
    				            <td>Cel. 7721288378</td>
    				            <td>nava_5355@hotmail.com</td>
    				        </tr>
    				        <tr>
    				            <th>Formación para catequistas</th>
    				            <td>Ernestina Ortega Monroy</td>
    				            <td>Cel. 7721192295</td>
    				            <td>soniarodriguezrodriguez13@gmail.com</td>
    				        </tr>
    				        <tr>
    				            <th>Escuela catequeticas</th>
    				            <td>María Ana Mendoza Maldonado</td>
    				            <td>Cel. 7727363015</td>
    				            <td>mema1303_495@hotmail.com</td>
    				        </tr>
    				    </tbody>
    				</table>
    			</div>
    		</div>
    	</div>
	</div>
	
	<!-- ##### Fin del área de modales ##### -->

    <!-- ##### Subscribe Area Start ##### -->
    <?php include 'subscribe-area.php' ?>
    <!-- ##### Subscribe Area End ##### -->

    <!-- ##### Footer Area Start ##### -->
    <?php include 'footer.php' ?>
    <!-- ##### Footer Area End ##### -->

    <!-- ##### All Javascript Script ##### -->
    <!-- jQuery-2.2.4 js -->
    <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="js/bootstrap/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="js/bootstrap/bootstrap.min.js"></script>
    <!-- All Plugins js -->
    <script src="js/plugins/plugins.js"></script>
    <!-- Active js -->
    <script src="js/active.js"></script>
</body>

</html>